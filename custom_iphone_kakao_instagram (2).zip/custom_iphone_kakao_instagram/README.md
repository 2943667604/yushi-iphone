# 自定义 iPhone + KakaoTalk + 相册 + Instagram 网页

这是一个独立的 HTML/CSS/JavaScript 可运行模板，参考了你发来的截图中的：
- iPhone 风格锁屏通知和上滑密码解锁
- iOS 桌面、小组件、Dock
- KakaoTalk 风格聊天列表和聊天窗口
- iOS 照片图库网格和照片预览
- Instagram 风格个人主页和帖子网格
- 模拟来电、语音消息、设置页

说明：这是按截图重建的原创模拟页面，不是苹果、KakaoTalk 或 Instagram 的官方程序，也不是原网页源码。手机通话为模拟效果，不会真实拨号。原网页未提供的细节无法保证逐像素一致。

## 文件结构

```text
custom_iphone_kakao_instagram/
├── index.html
├── style.css
├── app.js
├── config.js       # 主要改这里
└── assets/         # 放自己的图片/音频
```

## 从零运行

1. 下载并解压 ZIP。
2. 将你自己的图片放入 `assets/` 文件夹。
3. 用 VS Code 打开解压后的整个文件夹。
4. 最简单的方法：双击 `index.html` 用浏览器打开。
5. 推荐方法：在 VS Code 扩展商店安装 **Live Server**，右键 `index.html` → **Open with Live Server**。
6. 在手机上测试时，把项目放到静态托管平台（例如 GitHub Pages 或 Cloudflare Pages）后访问网址。只在电脑本地打开的文件，手机无法直接访问。

## 怎么更换照片

把图片放进 `assets/`，例如：
- `assets/galaxy-wallpaper.jpg`：锁屏和桌面壁纸
- `assets/character-avatar.jpg`：人物头像
- `assets/photo-1.jpg` 到 `assets/photo-9.jpg`：相册/Instagram 图片
- `assets/voice-1.mp3`：语音消息

文件名必须和 `config.js` 里写的一致。若你的图片是 PNG，就把路径也写成 `.png`。

## 怎么改人物与对话

打开 `config.js`：
- `character.name`：人物名称
- `character.avatar`：人物头像
- `wallpaper`：壁纸
- `lockNotifications`：锁屏通知
- `chats`：KakaoTalk 聊天列表、预览和未读数
- `messages`：每个聊天窗口的历史消息
- `photos`：相册图片和标题
- `instagram`：Instagram 用户名、简介和帖子
- `call.lines`：接通后的模拟通话文字
- `voiceMessages`：音频消息文件

聊天对象 `chats` 中的 `id` 必须与 `messages` 里的键名一致，例如 `id:"sohee"` 对应 `messages.sohee`。

## 密码

默认密码是 `1234`，在 `config.js` 顶部修改 `passcode` 即可。此密码只用于网页演示，不是安全认证。

## 注意

- 网页设置中的临时上传/更换图片只在当前页面会话有效；要永久保存，请将图片放进 `assets/` 并修改 `config.js`。
- 请确保你有权使用自己添加的图片、音频和头像。
